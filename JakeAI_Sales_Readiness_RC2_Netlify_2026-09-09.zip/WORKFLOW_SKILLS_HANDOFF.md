# JakeAI Workflow Skills Update — Handoff

Generated: 2026-09-09

## What changed
- Added 19 packaged Autonomous Workflow Skills.
- Added each skill to `GENESIS_CATALOG` in `main.py`.
- Added `/skills/{filename}` route for Markdown skill packages.
- Added an Autonomous Workflow Skills storefront section to `index.html`.
- Added machine-discovery entries to `llms.txt`.
- Added `workflow-skills.json` bulk manifest.
- Added individual skill packages under `/skills/`.

## Pricing
One-time prices range from $9 to $49. The parent AI Video Production Director is $49; specialized child skills are $12–$29; business/cloud workflows are $9–$29.

## Important deployment note
This update preserves the existing Stripe Checkout behavior: after successful checkout, the `download_url` is used as Stripe's success URL. The package URLs are not cryptographically gated; this matches the current MVP delivery pattern and should be hardened later if protected delivery becomes a requirement.

## Not changed
- Existing products
- Existing Stripe keys/configuration
- Railway configuration
- Existing legal pages
- Existing API solvers
