# JakeAI Sales Readiness RC2 — Netlify Source-of-Truth Repair

## Diagnosis
Railway successfully deployed RC1, but the public JakeAIOfficial.com storefront continued sending checkout clicks to a Netlify-local `/v1/checkout/buy/...` path. That indicates the public frontend was not serving the same updated `index.html` that Railway received, or Netlify was publishing/caching a different source/publish directory.

## Changes in RC2
- Added `netlify.toml` with explicit `publish = "."`.
- Added explicit Netlify proxy rules for `/v1/*`, `/api/v1/*`, health, docs, and llms.txt.
- Preserved `_redirects` as a second compatible routing layer.
- Added no-cache headers for `/` and `/index.html` so a stale storefront is less likely to remain live after deploy.
- Added `/version.json` as a deployment fingerprint.
- Re-verified every storefront checkout link points directly to:
  `https://agent-commerce-network-production-56e8.up.railway.app/v1/checkout/buy/<product_id>`
- No intentional visual/CSS/background/layout changes.

## Verify after Netlify deploy
1. Visit `https://www.jakeaiofficial.com/version.json`.
   It must show release `sales-readiness-rc2-netlify`.
2. Hard refresh the homepage.
3. Inspect/click one Buy button. Its destination should be on `agent-commerce-network-production-56e8.up.railway.app`, not on `jakeaiofficial.com/v1/...`.
4. Confirm Stripe Checkout appears.
5. Test one old product and one new workflow skill.
6. Only after both reach Stripe should we run a low-dollar end-to-end owner purchase.

## If version.json is 404 or shows an older release
Netlify is deploying from a different repository, branch, base directory, or publish directory than the files being uploaded to GitHub. Do not change Stripe or FastAPI; fix the Netlify Git source/deploy settings first.
