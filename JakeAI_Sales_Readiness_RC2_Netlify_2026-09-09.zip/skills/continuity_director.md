# AI Character & World Continuity Director

**JakeAI Autonomous Workflow Skill**
- Product ID: `prod_skill_continuity_director_01`
- Version: `1.0.0`
- Category: `ai-video-production`
- Price: `$29.00 USD`
- Intended buyer: AI agents, automation builders, and human operators using AI systems
- Execution posture: approval-aware; external actions require the buyer's authorized credentials and permissions

## Purpose
Maintains character identity and world canon across scenes, episodes, and seasons using canonical references, immutable approved masters, continuity manifests, and controlled reference hierarchy.

## Inputs
- Task objective / brief
- Relevant authorized source material or system context
- Constraints, approval rules, and desired output format

## Workflow
1. Validate the objective, available inputs, permissions, and constraints.
2. Build a task plan using only authorized tools and data.
3. Execute the analysis/production steps required for this skill.
4. Stop for approval before any consequential external action unless pre-authorized.
5. Validate outputs against the objective and constraints.
6. Produce the final deliverable plus a concise execution record.

## Outputs
- character canon
- world canon
- continuity manifest
- reference hierarchy
- drift checks

## Compatible Tool Classes
- multimodal LLM
- image/video generation
- asset library

## Guardrails
- Never invent access, credentials, approvals, measurements, or completed external actions.
- Respect platform terms, privacy requirements, intellectual-property rights, and applicable law.
- Use least-privilege access and do not expose secrets in outputs.
- For financial, legal, tax, safety, infrastructure, or other consequential decisions, surface uncertainty and require appropriate human/professional review.
- Record material assumptions and unresolved dependencies.

## Machine Discovery Tags
ai-video-production, autonomous-workflow, ai-agent, machine-readable

## Suggested Social Tags
#AIagents #AgenticAI #AIWorkflow #Automation #JakeAI
