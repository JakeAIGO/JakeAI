import unittest
from verifier import verify
M={"mandate_id":"m","currency":"USD","max_total":"100","allowed_merchants":["A"],"allow_recurring":False,"items":[{"sku":"X","max_quantity":2,"max_unit_price":"40"}]}
B={"merchant":"A","currency":"USD","total":"40","recurring":False,"items":[{"sku":"X","quantity":1,"unit_price":"40"}]}
class T(unittest.TestCase):
 def test_ok(self):self.assertEqual(verify(M,B)["decision"],"AUTHORIZED")
 def test_amount(self):self.assertEqual(verify(M,dict(B,total="101"))["decision"],"AMOUNT_ESCAPE")
 def test_merchant(self):self.assertEqual(verify(M,dict(B,merchant="B"))["decision"],"MERCHANT_ESCAPE")
 def test_item(self):self.assertEqual(verify(M,dict(B,items=[{"sku":"Y"}]))["decision"],"ITEM_ESCAPE")
 def test_recurring(self):self.assertEqual(verify(M,dict(B,recurring=True))["decision"],"RECURRING_NOT_AUTHORIZED")
 def test_quantity(self):self.assertEqual(verify(M,dict(B,items=[{"sku":"X","quantity":3,"unit_price":"20"}]))["decision"],"QUANTITY_ESCAPE")
 def test_deterministic(self):self.assertEqual(verify(M,B)["evidence_digest"],verify(M,B)["evidence_digest"])
