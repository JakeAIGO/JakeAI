# JakeAI Agent Mandate Verifier v0.1
Deterministic, provider-independent pre-transaction verifier for autonomous agents.

It does not execute payments. It compares an authorized mandate with a proposed transaction and emits an auditable JSON decision.

Decisions: AUTHORIZED, MANDATE_INCOMPLETE, EXPIRED, CURRENCY_ESCAPE, AMOUNT_ESCAPE, MERCHANT_ESCAPE, ITEM_ESCAPE, QUANTITY_ESCAPE, RECURRING_NOT_AUTHORIZED, SUBSTITUTION_NOT_AUTHORIZED.

Run: `python verifier.py mandate.json transaction-authorized.json`
Test: `python -m unittest -v test_verifier.py`

Boundary: adapters can normalize AP2, Mastercard Agent Pay, Visa TAP, x402 or conventional checkout data into the deterministic core. This package is not a payment processor and does not hold credentials.

Commercial hypothesis:
- local verifier: free
- hosted signed-verification API: $29/month
- team CI/commerce assurance: $99/month
- enterprise/custom adapters: quote

No public release, checkout activation, external contact, or spend is included.
