import hashlib,json
from decimal import Decimal

ORDER=["MANDATE_INCOMPLETE","EXPIRED","CURRENCY_ESCAPE","AMOUNT_ESCAPE","MERCHANT_ESCAPE","ITEM_ESCAPE","QUANTITY_ESCAPE","RECURRING_NOT_AUTHORIZED","SUBSTITUTION_NOT_AUTHORIZED"]
def norm(x): return str(x or "").strip().casefold()
def verify(m,t):
    f=[]
    missing=[k for k in ("mandate_id","currency","max_total","allowed_merchants","items") if k not in m]
    if missing:f.append({"code":"MANDATE_INCOMPLETE","detail":{"missing":missing}})
    if m.get("expires_at") and t.get("timestamp") and t["timestamp"]>m["expires_at"]:f.append({"code":"EXPIRED","detail":{}})
    if norm(t.get("currency"))!=norm(m.get("currency")):f.append({"code":"CURRENCY_ESCAPE","detail":{}})
    try:
        if Decimal(str(t.get("total"))) > Decimal(str(m.get("max_total"))):f.append({"code":"AMOUNT_ESCAPE","detail":{"max":str(m.get("max_total")),"actual":str(t.get("total"))}})
    except: f.append({"code":"MANDATE_INCOMPLETE","detail":{"field":"amount"}})
    if norm(t.get("merchant")) not in {norm(x) for x in m.get("allowed_merchants",[])}:f.append({"code":"MERCHANT_ESCAPE","detail":{"actual":t.get("merchant")}})
    allowed={norm(i.get("sku") or i.get("name")):i for i in m.get("items",[])}
    for i in t.get("items",[]):
        k=norm(i.get("sku") or i.get("name")); src=norm(i.get("substitutes_for"))
        base=allowed.get(k) or (allowed.get(src) if m.get("allow_substitutions") else None)
        if not base:f.append({"code":"ITEM_ESCAPE","detail":{"item":k}});continue
        if int(i.get("quantity",1))>int(base.get("max_quantity",1)):f.append({"code":"QUANTITY_ESCAPE","detail":{"item":k}})
        if base.get("max_unit_price") is not None and Decimal(str(i.get("unit_price",0)))>Decimal(str(base["max_unit_price"])):f.append({"code":"AMOUNT_ESCAPE","detail":{"item":k}})
        if src and not m.get("allow_substitutions",False):f.append({"code":"SUBSTITUTION_NOT_AUTHORIZED","detail":{"item":k}})
    if t.get("recurring",False) and not m.get("allow_recurring",False):f.append({"code":"RECURRING_NOT_AUTHORIZED","detail":{}})
    f.sort(key=lambda x:(ORDER.index(x["code"]) if x["code"] in ORDER else 999,json.dumps(x,sort_keys=True)))
    out={"mandate_id":m.get("mandate_id"),"decision":"AUTHORIZED" if not f else f[0]["code"],"failures":f,
         "mandate_digest":hashlib.sha256(json.dumps(m,sort_keys=True,separators=(",",":")).encode()).hexdigest(),
         "transaction_digest":hashlib.sha256(json.dumps(t,sort_keys=True,separators=(",",":")).encode()).hexdigest(),
         "verifier":"JakeAI-Agent-Mandate-Verifier/0.1"}
    out["evidence_digest"]=hashlib.sha256(json.dumps(out,sort_keys=True,separators=(",",":")).encode()).hexdigest()
    return out
if __name__=="__main__":
 import argparse
 p=argparse.ArgumentParser();p.add_argument("mandate");p.add_argument("transaction");a=p.parse_args()
 print(json.dumps(verify(json.load(open(a.mandate)),json.load(open(a.transaction))),indent=2,sort_keys=True))
